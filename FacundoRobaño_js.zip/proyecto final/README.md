# La Repulgue 🥟

Simulador de pedidos online para una casa de empanadas. Proyecto final del curso de JavaScript.

## Qué se puede hacer

1. Ver el menú de empanadas y filtrarlo por categoría (carne, pollo, verdura, jamón y queso).
2. Agregar empanadas al pedido.
3. Cambiar cantidades, eliminar empanadas o vaciar el pedido completo.
4. Elegir envío a domicilio (con costo de envío) o retiro en una sucursal.
5. Confirmar el pedido y ver el resumen final.

El pedido queda guardado en el navegador (localStorage), así que no se pierde al recargar la página.

## Cómo abrirlo

El menú y las sucursales se cargan con `fetch` desde archivos `.json`, por lo que **la página tiene que abrirse desde un servidor**. Si se abre `index.html` con doble clic, los datos no cargan.

- **Con VS Code:** instalar la extensión *Live Server*, hacer clic derecho en `index.html` y elegir *Open with Live Server*.
- **Online:** desde GitHub Pages, si está publicado.

## Estructura

```
index.html
assets/      imágenes (logo e ilustraciones de cada empanada)
css/         estilos propios
data/        empanadas.json y sucursales.json
js/          pedido.js (lógica del pedido y storage) e index.js (datos, DOM y eventos)
```

## Cómo cumple la consigna

- **DOM y eventos:** el menú, el pedido y los totales se dibujan dinámicamente. No se usa `prompt`, `alert` ni `confirm`.
- **JSON + fetch:** el menú (`data/empanadas.json`) y las sucursales (`data/sucursales.json`) se consumen con `fetch`. No hay arrays de objetos escritos en el JavaScript.
- **Funciones de orden superior:** `forEach`, `map`, `filter`, `find` y `reduce` para dibujar, filtrar, buscar y calcular totales.
- **Storage:** el pedido se guarda en `localStorage` al agregar, se modifica al cambiar cantidades, se borra por empanada y se vacía completo.
- **Operadores avanzados:** ternario, operador `||` y destructuring.
- **Asincronismo:** `async/await` con `try/catch/finally` al cargar los datos. Si falla la carga, se avisa en pantalla.
- **Librería externa:** SweetAlert2 para confirmaciones, avisos y el toast al agregar una empanada.
- **Circuito completo:** menú → agregar → modificar cantidades → elegir envío o retiro → total → confirmar.

## Probar el manejo de errores

Si se cambia el nombre de `data/empanadas.json` en `js/index.js`, la página muestra el mensaje "No pudimos cargar el menú" en lugar del catálogo. Con el pedido guardado en `localStorage` corrupto, la app lo descarta y arranca con el pedido vacío.

## Tecnologías

- HTML, CSS y JavaScript
- [Bootstrap 5](https://getbootstrap.com/) para la maquetación
- [SweetAlert2](https://sweetalert2.github.io/) para los mensajes y confirmaciones
- [Bootstrap Icons](https://icons.getbootstrap.com/) para los íconos de los botones

## Autor

Facundo Robaño
